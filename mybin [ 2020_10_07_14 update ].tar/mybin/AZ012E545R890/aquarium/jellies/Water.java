package aquarium.jellies;

public class Water {
	boolean salty = true;
	public Water() {
		System.out.println( "init : aquarium.jellies.Water : " );
		System.out.println( "       this.salty : " + this.salty + " : " );
	}
}
