#!/bin/python3

import os;
import sys;
import subprocess;

java_file_name = "Test";

# ------------------------------------------------------------------------------------------------------
#  info :: 01 :: Test.java content
# ------------------------------------------------------------------------------------------------------

Test_java_content = """

    import java.util.*;
    import java.util.function.*;
    import java.util.stream.*;
    import java.util.concurrent.*;
    //@import

    public class @java_file_name {
    
        //@field

        public static void main ( //@argu_str ) {

            //@content

        } // end method main

        //@method

    } // end class Test

    //@classes

""";

Test_java_content = Test_java_content.replace( "@java_file_name" , java_file_name );


# ------------------------------------------------------------------------------------------------------
#  info :: 0101 ::  read user argus
# ------------------------------------------------------------------------------------------------------

J_import  = [];
J_field   = [];
J_content = [];
J_method  = [];
J_classes = [];
J_argu    = [];
use_default_argu_or_not = True;

obj = [ o for o in sys.argv if ( len( o ) > 0 ) ];

for i in range( 1, len( obj ) ) :

	s = sys.argv[ i ];
	
	# print( "\n\ndebug using :: argv : [" + s + "]" );
	
	obj = "--jargu=";
	if( obj in s ) : 
		J_argu.append( s[ len( obj ): ].strip() );
		pass;
	
	obj = "--argu=";
	if( obj in s ) : 
		argu_str = s[ len( obj ): ].strip();
		use_default_argu_or_not = False;
		pass;
	
	obj = "--import=";
	if( obj in s ) : 
		J_import.append( s[ len( obj ): ].strip() );
		pass;
	
	obj = "--field=";
	if( obj in s ) : 
		J_field.append( s[ len( obj ): ].strip() );
		pass;
	
	obj = "--content=";
	if( obj in s ) : 
		J_content.append( s[ len( obj ): ].strip() );
		pass;
	
	obj = "--method=";
	if( obj in s ) : 
		J_method.append( s[ len( obj ): ].strip() );
		pass;
	
	obj = "--classes=";
	if( obj in s ) : 
		J_classes.append( s[ len( obj ): ].strip() );
		pass;
	
	pass;

if ( use_default_argu_or_not ) :
	Test_java_content = Test_java_content.replace( "//@argu_str"     , "String[] args" );
	pass;
else :
	Test_java_content = Test_java_content.replace( "//@argu_str"     , argu_str        );
	pass;
	
import_str = "";
pad   = "";
index = 0;
for J_s in J_import : 
	if ( index != 0 ) :
		pad = "\n    "
	import_str += ( pad + "\n    ".join( [ o.strip() + ";" for o in J_s.split( ";" ) if ( len( o.strip() ) > 0 ) ] ) );
	index += 1;
	pass;	
# print( "\n\ndebug using :: import_str :: [" + import_str + "]" );
Test_java_content = Test_java_content.replace( "//@import", import_str );


field_str = "";
pad   = "";
index = 0;
for J_f in J_field : 
	if ( index != 0 ) :
		pad = "\n        "
	field_str += ( pad + "\n        ".join( [ o.strip() + ";" for o in J_f.split( ";" ) if ( len( o.strip() ) > 0 ) ] ) );
	index += 1;
	pass;	
# print( "\n\ndebug using :: field_str :: [" + field_str + "]" );
Test_java_content = Test_java_content.replace( "//@field", field_str );


content_str = "";
pad   = "";
index = 0;
for J_c in J_content : 
	if ( index != 0 ) :
		pad = "\n            "
	content_str += ( pad + "\n            ".join( [ o.strip() + ";" for o in J_c.split( ";" ) if ( len( o.strip() ) > 0 ) ] ) );
	index += 1;
	pass;	
# print( "\n\ndebug using :: content_str :: [" + content_str + "]" );
Test_java_content = Test_java_content.replace( "//@content", content_str );


method_str = "";
pad   = "";
index = 0;
for J_m in J_method : 
	if ( index != 0 ) :
		pad = "\n        "
	method_str += ( pad + J_m.strip() );
	index += 1;
	pass;	
# print( "\n\ndebug using :: method_str :: [" + method_str + "]" );
Test_java_content = Test_java_content.replace( "//@method", method_str );


classes_str = "";
pad   = "";
index = 0;
for J_c in J_classes : 
	if ( index != 0 ) :
		pad = "\n    "
	classes_str += ( pad + J_c.strip().replace( "public class", "class" ) );
	index += 1;
	pass;	
# print( "\n\ndebug using :: classes_str :: [" + classes_str + "]" );
Test_java_content = Test_java_content.replace( "//@classes", classes_str );


j_argu_str = "";
index = 0;
for J_a in J_argu : 
	j_argu_str += ( " " + J_a + " " );
	index += 1;
	pass;	
# print( "\n\ndebug using :: j_argu_str :: [" + j_argu_str + "]" );


# ------------------------------------------------------------------------------------------------------
#  info :: 02 ::  write into Test.java at .
# ------------------------------------------------------------------------------------------------------

os.system( "echo '" + Test_java_content + "' > " + java_file_name + ".java" );


# ------------------------------------------------------------------------------------------------------
#  info :: 03 ::  compile Test.java
# ------------------------------------------------------------------------------------------------------
print( "\n====================================================================" );
print( "step 01 :: compile ing ..." );
print( "====================================================================\n" );
os.system( "javac " + java_file_name + ".java;" );


# ------------------------------------------------------------------------------------------------------
#  info :: 04 ::  run Test
# ------------------------------------------------------------------------------------------------------
print( "\n====================================================================" );
print( "step 02 :: run ing ..." );
print( "====================================================================\n" );
os.system( "java  " + java_file_name + " " + j_argu_str + ";" );


# ------------------------------------------------------------------------------------------------------
#  info :: 05 ::  restore envrionment
# ------------------------------------------------------------------------------------------------------
print( "\n====================================================================" );
print( "step 03 :: restore environment ing ..." );
print( "====================================================================\n" );
os.system( "rm -rf " + java_file_name + ".java" );
os.system( "rm -rf *.class" );
