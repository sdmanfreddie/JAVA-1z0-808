#!/bin/python3

import os;
import sys;
import subprocess;

# ls *.tar | tail -n 1

cmd  = "echo                                        ;\n";
cmd += "echo step 01 : mv ./mybin/*.tar to ../      ;\n";
cmd += "mv mybin*.tar ../                           ;\n";

cmd += "echo                                        ;\n";
cmd += "echo step 02 : cd to ../                    ;\n";
cmd += "cd ../                                      ;\n";

cmd += "echo                                        ;\n";
cmd += "echo step 03 : search newest .tar file      ;\n";
cmd += "file=$( ls mybin*.tar | tail -n 1 )         ;\n"
cmd += "echo restore file using this:[${file}]      ;\n"

cmd += "echo                                        ;\n";
cmd += "echo step 04 : start to restore             ;\n";
# cmd += "rm -rf ./mybin                            ;\n"
cmd += "tar -xf ${file}                             ;\n"

cmd += "echo                                        ;\n";
cmd += "echo step 05 : mv *.tar into ./mybin        ;\n";
cmd += "mv mybin*.tar ./mybin/                      ;\n";

os.system( cmd );
