
import lib.*;

public class Tank {
	public void print( Water water ) {
		System.out.println( "project [AZ012E54R889] : water hashcode : " + water );
	}
	public static void main ( String[] argu ) {
		new Tank().print( new Water() );
	}
}
