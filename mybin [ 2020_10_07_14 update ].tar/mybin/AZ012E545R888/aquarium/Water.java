package aquarium;

public class Water {
	public String getWater() {
		return "project [AZ012E54R888] : getting usa water ing ... ";
	}
}
