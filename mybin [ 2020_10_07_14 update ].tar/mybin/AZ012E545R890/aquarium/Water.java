package aquarium;

public class Water {
	boolean salty = false;
	public Water() {
		System.out.println( "init : aquarium.Water : " );
		System.out.println( "       this.salty : " + this.salty + " : " );
	}
}
