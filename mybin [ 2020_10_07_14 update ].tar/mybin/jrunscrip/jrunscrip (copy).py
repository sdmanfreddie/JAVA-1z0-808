#!/bin/python3

import os;
import sys;
import subprocess;

java_file_name = "Test";


# ------------------------------------------------------------------------------------------------------
#  info :: 01 :: Test.java content
# ------------------------------------------------------------------------------------------------------

Test_java_content = """

    import java.util.*;
    import java.util.function.*;
    import java.util.stream.*;
    import java.util.concurrent.*;
    //@import

    public class @java_file_name {

        public static void main ( String[] args ) {

            //@content

        } // end method main

        //@method

    } // end class Test

    //@classes

""";

Test_java_content = Test_java_content.replace( "@java_file_name", java_file_name );


# ------------------------------------------------------------------------------------------------------
#  info :: 0101 ::  read user argus
# ------------------------------------------------------------------------------------------------------

J_import  = [];
J_content = [];
J_method  = [];
J_classes = [];


obj = [ o for o in sys.argv if ( len( o ) > 0 ) ];

for i in range( 1, len( obj ) ) :

	s = sys.argv[ i ];
	
	# print( "\n\ndebug using :: argv : [" + s + "]" );
	
	if( "--import=" in s ) : 
	
		J_import.append( s[ 9: ].strip() );
	
		pass;
	
	if( "--content=" in s ) : 
	
		J_content.append( s[ 10: ].strip() );
	
		pass;
	
	if( "--method=" in s ) : 
	
		J_method.append( s[ 9: ].strip() );
	
		pass;
	
	if( "--classes=" in s ) : 
	
		J_classes.append( s[ 10: ].strip() );
	
		pass;
	
	pass;


import_str = "";
pad   = "";
index = 0;
for J_s in J_import : 
	if ( index != 0 ) :
		pad = "\n    "
	import_str += ( pad + "\n    ".join( [ o.strip() + ";" for o in J_s.split( ";" ) if ( len( o.strip() ) > 0 ) ] ) );
	index += 1;
	pass;	
# print( "\n\ndebug using :: import_str :: [" + import_str + "]" );
Test_java_content = Test_java_content.replace( "//@import", import_str );


content_str = "";
pad   = "";
index = 0;
for J_c in J_content : 
	if ( index != 0 ) :
		pad = "\n            "
	content_str += ( pad + "\n            ".join( [ o.strip() + ";" for o in J_c.split( ";" ) if ( len( o.strip() ) > 0 ) ] ) );
	index += 1;
	pass;	
# print( "\n\ndebug using :: content_str :: [" + content_str + "]" );
Test_java_content = Test_java_content.replace( "//@content", content_str );


method_str = "";
pad   = "";
index = 0;
for J_m in J_method : 
	if ( index != 0 ) :
		pad = "\n        "
	method_str += ( pad + J_m.strip() );
	index += 1;
	pass;	
# print( "\n\ndebug using :: method_str :: [" + method_str + "]" );
Test_java_content = Test_java_content.replace( "//@method", method_str );


classes_str = "";
pad   = "";
index = 0;
for J_c in J_classes : 
	if ( index != 0 ) :
		pad = "\n    "
	classes_str += ( pad + J_c.strip().replace( "public class", "class" ) );
	index += 1;
	pass;	
# print( "\n\ndebug using :: classes_str :: [" + classes_str + "]" );
Test_java_content = Test_java_content.replace( "//@classes", classes_str );


# ------------------------------------------------------------------------------------------------------
#  info :: 02 ::  write into Test.java at .
# ------------------------------------------------------------------------------------------------------

os.system( "echo '" + Test_java_content + "' > " + java_file_name + ".java" );


# ------------------------------------------------------------------------------------------------------
#  info :: 03 ::  compile Test.java
# ------------------------------------------------------------------------------------------------------
print( "\n====================================================================" );
print( "step 01 :: compile ing ..." );
print( "====================================================================\n" );
os.system( "javac " + java_file_name + ".java;" );


# ------------------------------------------------------------------------------------------------------
#  info :: 04 ::  run Test
# ------------------------------------------------------------------------------------------------------
print( "\n====================================================================" );
print( "step 02 :: run ing ..." );
print( "====================================================================\n" );
os.system( "java  " + java_file_name + ";" );


# ------------------------------------------------------------------------------------------------------
#  info :: 05 ::  restore envrionment
# ------------------------------------------------------------------------------------------------------
print( "\n====================================================================" );
print( "step 03 :: restore environment ing ..." );
print( "====================================================================\n" );
os.system( "rm -rf " + java_file_name + ".java" );
os.system( "rm -rf *.class" );
