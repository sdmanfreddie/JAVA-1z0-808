#!/bin/python3

import os;
import sys;
import subprocess;

date_str = subprocess.getoutput( "date +%Y_%m_%d_%H_%M" );

# ls *.tar | tail -n 1

cmd  = "echo                                        ;\n";
cmd += "echo step 01 : mv ./mybin/*.tar to ../      ;\n";
cmd += "mv mybin*.tar ../                           ;\n";

cmd += "echo                                        ;\n";
cmd += "echo step 02 : cd to ../                    ;\n";
cmd += "cd ../                                      ;\n";

cmd += "echo                                        ;\n";
cmd += "echo step 03 : tar ./mybin                  ;\n";
cmd += "tar -cf mybin[" + date_str + "].tar ./mybin ;\n"

cmd += "echo                                        ;\n";
cmd += "echo step 04 : mv *.tar into ./mybin        ;\n";
cmd += "mv mybin*.tar ./mybin/                      ;\n";

os.system( cmd );
