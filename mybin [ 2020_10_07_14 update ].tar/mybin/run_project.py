
import os;
import sys;
import subprocess;


# ========================================================================================================================================
#   info :: get current edit file
# ========================================================================================================================================

this_file1 = sys.argv[0];
this_file2 = this_file1[ 0 : this_file1.index( "." ) ];


# ========================================================================================================================================
#   info :: get workspace and java, javac argus
# ========================================================================================================================================

workspace = "";

cp_list      = [];
compile_file = "";
run_file     = "";
project_n    = "AZ012E545R888";
project_s    = "";

if ( len( sys.argv ) > 1 ) :

	for argvs in sys.argv[1:] : 
	
		if ( "--workspace=" in argvs ) :
		
			workspace = argvs[ argvs.index( "=" ) + 1 : ];
		
			pass;
			
		if ( "--proj=" in argvs ) :
		
			project_n = argvs[ argvs.index( "=" ) + 1 : ];
		
			pass;
			
		if ( "--cp=" in argvs ) :
		
			cp_list.append( argvs[ argvs.index( "=" ) + 1 : ] );
		
			pass;
			
		if ( "--file=" in argvs ) :
		
			compile_file = argvs[ argvs.index( "=" ) + 1 : ];
		
			pass;
	
		if ( "--run=" in argvs ) :
		
			run_file = argvs[ argvs.index( "=" ) + 1 : ];
		
			pass;
	
		pass;
	
	pass;
	
for o1 in os.walk( workspace ) : 
	for o2 in o1[1] : 
		if ( o2 == project_n ) : 
			project_s = o1[0] + "/" + o2 + "/";
			project_s = os.path.abspath( project_s );
			pass;
		pass;
	pass;


# ========================================================================================================================================
#   info :: debug area
# ========================================================================================================================================

# debug using ======================================================================================
# print( "debug using :: py01 :: workspace    :: [ " + workspace  + " ]" );
# print( "debug using :: py02 :: project_n    :: [ " + project_n  + " ]" );
# print( "debug using :: py03 :: project_s    :: [ " + project_s  + " ]" );
# print( "debug using :: py04 :: cp_list      :: [ " + str( cp_list )       + " ]" );
# print( "debug using :: py05 :: compile_file :: [ " + str( compile_file )  + " ]" );
# print( "debug using :: py06 :: run_file     :: [ " + str( run_file )      + " ]" );
# debug using ======================================================================================


# ========================================================================================================================================
#   info :: compile and running
# ========================================================================================================================================

cp_path = "";
if( len( cp_list ) > 0 ) :
	cp_path = "-cp \"" + ";".join( cp_list ) + "\"";
	pass;


print( "\n\nstep 1 : compile ing " );
print( "-----------------------------------------------------------------------" );
cmd  = " cd '" + project_s + "' ;\n";
cmd += " javac " + cp_path + " '" + compile_file + "' ;\n";
os.system( cmd );


print( "\n\nstep 2 : run     ing " );
print( "-----------------------------------------------------------------------" );
cmd  = " cd '" + project_s + "' ;\n";
cmd += " java " + cp_path + " \"" + run_file     + "\" ;\n";
# print( "java cmd : " + cmd );
os.system( cmd );
print( "" );
print( "" );


