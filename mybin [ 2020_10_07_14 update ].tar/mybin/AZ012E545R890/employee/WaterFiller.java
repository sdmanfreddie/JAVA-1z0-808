package employee;

// A :: 
//------------------------------------
	// import aquarium.*;

// B :: 
//------------------------------------
	// import aquarium.Water;
	// import aquarium.jellies.*;

// C :: 
//------------------------------------
	import aquarium.*;
	import aquarium.jellies.Water;

// D :: 
//------------------------------------
	// import aquarium.*;
	// import aquarium.jellies.*;

public class WaterFiller {
	Water water;
	public static void main ( String[] argu ) {
		WaterFiller test = new WaterFiller();
		test.water = new Water();
	}
}
