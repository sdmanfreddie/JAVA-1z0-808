
	import lib.Tool;
	
	public class Test {
	
		public static void main ( String[] argu ) {
		
			try {
			
				// System.out.println( new Tool( "0123456789" ).getSubString( -1,5 ) );
				
				System.out.println( new Tool( "0123456789" ).getSubString( 1,5 ) );
				
			} catch ( Exception e ) {
			
				e.printStackTrace();
			
			}
		
		} // end method main
	
	} // end class Test
