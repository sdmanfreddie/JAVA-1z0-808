package aquarium;

public class Tank {
  public void print( Water water ) {
    System.out.println( water.getWater() );
  }
  public static void main ( String[] argu ) {
  	new Tank().print( new Water() );
  }
}
