
	package named.A;

	public class Bird {
		public static void main ( String[] argu ) {
			System.out.println( "Entry point in Bird.java :: " );
		}
	}
