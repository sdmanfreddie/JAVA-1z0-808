
	package lib;
	
	public class Tool {
	
		private String value;
	
		public Tool ( String v ) {
		
			this.value = v;
		
		} // end constructor
	
		public String getSubString( int startPoint, int endPoint ) throws Exception {
		
			if ( endPoint < startPoint )              throw new Exception ( "error 01 : please check range of your startPoint, endPoint :: " );
		
			if ( startPoint < 0 )                     throw new Exception ( "error 02 : startPoint must be > 0 :: " );
		
			if ( endPoint > this.value.length() - 1 ) throw new Exception ( "error 03 : endPoint must be <= str.length() - 1 :: " );
		
			StringBuffer sb = new StringBuffer();
		
			for ( int i = startPoint ; i <= endPoint ; i++ ) {
				sb.append( this.value.charAt( i ) );
			}
		
			return sb.toString();
		
		} // end method 
	
	} // end class Tool
